package com.example.pvpmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class AdvancedPvPMod implements ClientModInitializer {
    public static boolean critPacketEnabled = true;
    public static boolean smoothRotationsEnabled = true;
    public static boolean cpsRandomizerEnabled = true;

    public static final int BUTTON_X = 10;
    public static final int BUTTON_Y = 60;
    public static final int BUTTON_SIZE = 30;

    private static KeyBinding toggleMenuKey;
    private static KeyBinding toggleModKey;

    @Override
    public void onInitializeClient() {
        toggleMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.advancedpvp.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.advancedpvp"
        ));

        toggleModKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.advancedpvp.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.advancedpvp"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (toggleMenuKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new PvPConfigScreen());
                }
            }

            if (toggleModKey.wasPressed()) {
                critPacketEnabled = !critPacketEnabled;
                smoothRotationsEnabled = !smoothRotationsEnabled;
                cpsRandomizerEnabled = !cpsRandomizerEnabled;
            }

            if (cpsRandomizerEnabled) {
                CombatManager.tick();
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && !announced) {
                announced = true;
                client.player.sendMessage(Text.literal("[AdvancedPvP] Mod yuklandi. Chapdagi PvP tugmasini bosing."), false);
            }
        });

        HudRenderCallback.EVENT.register(AdvancedPvPMod::renderToggleButton);
    }

    private static boolean announced = false;

    private static void renderToggleButton(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.currentScreen != null || client.player == null) {
            return;
        }

        context.fill(BUTTON_X, BUTTON_Y, BUTTON_X + BUTTON_SIZE, BUTTON_Y + BUTTON_SIZE, 0xFFFF3030);
        context.drawBorder(BUTTON_X, BUTTON_Y, BUTTON_SIZE, BUTTON_SIZE, 0xFFFFFFFF);
        context.drawText(client.textRenderer, Text.literal("PvP"), BUTTON_X + 4, BUTTON_Y + 11, 0xFFFFFF, true);
    }
}
