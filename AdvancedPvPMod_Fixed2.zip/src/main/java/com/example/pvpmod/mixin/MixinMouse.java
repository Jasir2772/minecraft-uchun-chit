package com.example.pvpmod.mixin;

import com.example.pvpmod.AdvancedPvPMod;
import com.example.pvpmod.PvPConfigScreen;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MixinMouse {

    @Shadow
    private double x;

    @Shadow
    private double y;

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void advancedpvp$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || action != GLFW.GLFW_PRESS) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.currentScreen != null || client.player == null) {
            return;
        }

        double scaleX = (double) client.getWindow().getScaledWidth() / (double) client.getWindow().getWidth();
        double scaleY = (double) client.getWindow().getScaledHeight() / (double) client.getWindow().getHeight();
        double mouseX = this.x * scaleX;
        double mouseY = this.y * scaleY;

        if (mouseX >= AdvancedPvPMod.BUTTON_X && mouseX <= AdvancedPvPMod.BUTTON_X + AdvancedPvPMod.BUTTON_SIZE
                && mouseY >= AdvancedPvPMod.BUTTON_Y && mouseY <= AdvancedPvPMod.BUTTON_Y + AdvancedPvPMod.BUTTON_SIZE) {
            client.setScreen(new PvPConfigScreen());
            ci.cancel();
        }
    }
}
